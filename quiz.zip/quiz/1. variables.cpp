#include <iostream>
using namespace std;

int main() {
    // declaracion, inicializacion de variables
    int num1 = 10, num2 = 25;
    // variables enteras
    float decimal1 = 3.14, decimal2 = 7.5;
    // variables flotantes
    char letra = 'A';
    // variable de tipo caracter

    // imprimir valores en consola
    cout << "enteros: " << num1 << ", " << num2 << endl;
    cout << "flotantes: " << decimal1 << ", " << decimal2 << endl;
    cout << "caracter: " << letra << endl;

    return 0;
}

// int guarda numeros enteros sin decimales
// float guarda numeros con decimales
// char guarda un solo caracter